package com.example.yuva.searchnow;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Display extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
   RecyclerView rv;
   ImageAdapter mImageAdapter;
    List<Data> dataList;
    String editquery;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        editquery=getIntent().getStringExtra("query");
        rv=findViewById(R.id.rv);
        GridLayoutManager manager=new GridLayoutManager(this,2);
        rv.setLayoutManager(manager);
        rv.setHasFixedSize(true);
        if(isNetworkAvailable())
            getSupportLoaderManager().initLoader(1,null,this);
        else{
            AlertDialog.Builder builder;

                builder = new AlertDialog.Builder(this);

            builder.setTitle("Connection Problem!")
                    .setMessage("Please make sure you are connected to internet..").setCancelable(true);
                    /*.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // continue with delete
                        }
                    })
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // do nothing
                        }
                    });*/
                    //.setIcon(android.R.drawable.ic_dialog_alert)
                    //.show();
        }

    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        return new AsyncTaskLoader<String>(this) {
            protected void onStartLoading() {
                super.onStartLoading();
                Toast.makeText(Display.this, "Loading..", Toast.LENGTH_SHORT).show();
                forceLoad();
            }
            @Nullable
            @Override
            public String loadInBackground() {
                try {
                    URL url1 = NetworkUtils.buildUrl(editquery);
                    HttpURLConnection connection = (HttpURLConnection) url1.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();
                    InputStream is = connection.getInputStream();
                    StringBuilder builder = new StringBuilder();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        builder.append(line);
                    }
                    return builder.toString();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        //Toast.makeText(this, ""+data, Toast.LENGTH_SHORT).show();
        try {
            dataList = new ArrayList<>();
            JSONObject jsonObject=new JSONObject(data);
            JSONArray hits=jsonObject.getJSONArray("hits");
            for(int i=0;i<hits.length();i++){
                Data currentdata = new Data();
                JSONObject position=hits.getJSONObject(i);
                String image=position.getString("previewURL");
                currentdata.setImage1(image);
                dataList.add(currentdata);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        mImageAdapter=new ImageAdapter(getApplicationContext(),dataList);
        rv.setAdapter(mImageAdapter);

    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
