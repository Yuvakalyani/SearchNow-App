package com.example.yuva.searchnow;

import android.net.Uri;

import java.net.MalformedURLException;
import java.net.URL;

public class NetworkUtils {

    final static String Base_url="https://pixabay.com/api/?key=10745885-5f7a88d3d902593c7d3133e60";
    final static String PARAM_QUERY = "q";

    public static URL buildUrl(String queryUrl){
        Uri buildUri=Uri.parse(Base_url).buildUpon().appendQueryParameter(PARAM_QUERY,queryUrl).build();

        URL url=null;
        try {
            url=new URL(buildUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return url;
    }
}
