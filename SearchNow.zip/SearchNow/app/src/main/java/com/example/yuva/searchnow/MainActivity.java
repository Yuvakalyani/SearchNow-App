package com.example.yuva.searchnow;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{
   EditText query;
    String editquery;
    List<Data> dataList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        query=(EditText)findViewById(R.id.edit_query);
    }

    public void onclickfun(View view) {
         editquery=query.getText().toString();
        if(editquery.isEmpty()){
            Toast.makeText(this, "Please Enter Something!", Toast.LENGTH_SHORT).show();
        }
        else {

           // getSupportLoaderManager().initLoader(1,null,MainActivity.this);
            Intent i = new Intent(this, Display.class);
            //ArrayList<Data> dataArray=new ArrayList<>(dataList);
            //i.putParcelableArrayListExtra("data",dataArray);
            i.putExtra("query",editquery);
            startActivity(i);
        }
    }

}
