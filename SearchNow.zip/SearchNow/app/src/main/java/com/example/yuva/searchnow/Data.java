package com.example.yuva.searchnow;

import android.os.Parcel;
import android.os.Parcelable;

public class Data implements Parcelable {
    String image;
    public  Data(){}

    protected Data(Parcel in) {
        image = in.readString();
    }

    public static final Creator<Data> CREATOR = new Creator<Data>() {
        @Override
        public Data createFromParcel(Parcel in) {
            return new Data(in);
        }

        @Override
        public Data[] newArray(int size) {
            return new Data[size];
        }
    };
    public String getImage() {
        return image;
    }
    public void setImage1(String image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(image);
    }
}
